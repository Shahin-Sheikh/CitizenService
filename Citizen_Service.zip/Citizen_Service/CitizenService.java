import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class CitizenService{
	public static void main(String [] args){
		FirstPage f= new FirstPage();
		f.setVisible(true);
	}
}
